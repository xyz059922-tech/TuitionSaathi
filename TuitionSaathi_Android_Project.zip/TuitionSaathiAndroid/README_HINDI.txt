TUITION SAATHI - PHONE-ONLY APK BUILD TEMPLATE

Yeh source project hai, APK nahi. APK ko GitHub Actions ke free cloud build se banaya ja sakta hai.

PHONE SE STEPS:
1. ZIP ko extract karne ki zarurat nahi jab tak GitHub repo mein files upload karne ka tareeqa na chunen.
2. GitHub account kholen aur New repository banayen. Repository ka naam TuitionSaathi rakhen. Private repository chun sakte hain.
3. Is ZIP ko phone mein extract karen. GitHub website par repo mein files/folders upload karen; ZIP file ko seedha upload karne se project apne-aap extract nahi hoga.
4. Root mein settings.gradle.kts, build.gradle.kts, gradle.properties, app folder aur .github folder sab maujood hone chahiye.
5. Upload ke baad Actions tab kholen, workflow 'Build Tuition Saathi APK' select karen aur Run workflow dabayen.
6. Build successful hone par workflow run ke neeche Artifacts mein Tuition-Saathi-APK download karen. ZIP artifact ke andar app-debug.apk milega.
7. APK ko install karne se pehle trusted source aur file ka dhyan rakhen. Phone poochhe to browser/file manager ke liye 'Install unknown apps' permission allow karni pad sakti hai; kaam ke baad permission band kar den.

NOTES:
- Yeh personal-use debug APK hai, Play Store release bundle nahi.
- App data phone ke app ke andar local rahega. App uninstall ya app data clear karne se data mit sakta hai; backup regularly banayen.
- Backup/CSV Downloads/TuitionSaathi folder mein save hoga; Restore file picker se JSON choose karega.
- Printing Android print dialog kholne ke liye designed hai.
- GitHub Actions free limits/policies badal sakti hain; build fail ho to error log dekhna hoga.
- Play Store publication ke liye baad mein signed release AAB, privacy policy aur testing requirements alag se karni hongi.
